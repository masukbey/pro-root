//! ICS 24: Host defines the minimal set of interfaces that a
//! state machine hosting an IBC-enabled chain must implement.

pub mod identifier;
pub mod path;
