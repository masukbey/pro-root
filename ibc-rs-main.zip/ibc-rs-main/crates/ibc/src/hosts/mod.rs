//! Provides convenience implementations for various hosts
pub mod tendermint;
