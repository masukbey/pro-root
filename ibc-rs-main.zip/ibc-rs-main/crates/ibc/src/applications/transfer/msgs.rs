//! Defines the token transfer message type

pub mod transfer;
