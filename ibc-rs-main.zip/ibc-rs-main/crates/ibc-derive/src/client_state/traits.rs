//! Hosts the code generation of the `impl`s for the `ClientState` traits

pub mod client_state_common;
pub mod client_state_execution;
pub mod client_state_validation;
