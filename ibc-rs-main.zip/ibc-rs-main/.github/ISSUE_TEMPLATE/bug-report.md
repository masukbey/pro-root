---
name: Bug Report 
about: Create a report to help us squash bugs!

---

<!-- < < < < < < < < < < < < < < < < < < < < < < < < < < < < < < < < < ☺ 
v               ✰  Thanks for opening an issue! ✰    
v    Before smashing the submit button please review the template.
v    Please also ensure that this is not a duplicate issue :)  
☺ > > > > > > > > > > > > > > > > > > > > > > > > > > > > > > > > >  -->

## Bug Summary

<!-- Provide a short description of the issue you're encountering -->

## Details

<!-- Add details needed to reproduce the issue here -->

## Version

<!-- ibc-rs release version or git commit hash -->
