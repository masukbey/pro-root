---
name: Feature Request
about: Create a proposal to request a feature!

---

<!-- < < < < < < < < < < < < < < < < < < < < < < < < < < < < < < < < < ☺ 
v                ✰  Thanks for opening an issue! ✰    
v    Before smashing the submit button please review the template.
v    Word of caution: poorly thought-out proposals may be rejected 
v                     without deliberation 
☺ > > > > > > > > > > > > > > > > > > > > > > > > > > > > > > > > >  -->

## Feature Summary

<!-- Short description of the proposed feature -->

## Proposal

<!-- Provide a full description and requirements of the feature -->
