- Refactor and fix version validation in connection and channel handshakes
([#625](https://github.com/cosmos/ibc-rs/issues/625))