- Remove `store_client_type` interface as it is not included in the IBC spec anymore.
  ([#592](https://github.com/cosmos/ibc-rs/issues/592))
