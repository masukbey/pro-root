- Make token transfer events compatible with latest ibc-go
  ([#495](https://github.com/cosmos/ibc-rs/pull/495))
