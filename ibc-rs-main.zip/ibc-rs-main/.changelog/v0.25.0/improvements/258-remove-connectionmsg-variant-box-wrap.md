- ConnectionMsg::ConnectionOpen{Try, Ack} should not wrap a Box
  ([#258](https://github.com/cosmos/ibc-rs/issues/258))