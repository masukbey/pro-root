- Track code coverage with `cargo-llvm-cov`
  ([#277](https://github.com/cosmos/ibc-rs/issues/277))