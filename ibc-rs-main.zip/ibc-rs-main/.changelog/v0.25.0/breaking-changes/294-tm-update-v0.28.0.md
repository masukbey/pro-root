- Update `tendermint` dependencies to `v0.28.0`, which contain an important security fix.
([#294](https://github.com/cosmos/ibc-rs/issues/294))