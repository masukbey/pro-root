- Implement the IBC misbehaviour handler and misbehaviour handling logic for the Tendermint light client.
  ([#12](https://github.com/cosmos/ibc-rs/issues/12))