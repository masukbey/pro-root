- Rename Ics* names to something more descriptive
  ([#245](https://github.com/cosmos/ibc-rs/issues/245))