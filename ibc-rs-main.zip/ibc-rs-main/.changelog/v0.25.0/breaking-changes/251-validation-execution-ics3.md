- Implement `ValidationContext::validate` and `ExecutionContext::execute` for connections (ICS-3)
  ([#251](https://github.com/cosmos/ibc-rs/issues/251))
