- Verify the message's counterparty connection ID in `conn_open_ack`
  instead of the store's ([#274](https://github.com/cosmos/ibc-rs/issues/274))
