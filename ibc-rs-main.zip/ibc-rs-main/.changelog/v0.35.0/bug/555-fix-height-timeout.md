- Timeout handler returns an error only when both height and timestamp have not
  reached yet ([#555](https://github.com/cosmos/ibc-rs/issues/555))