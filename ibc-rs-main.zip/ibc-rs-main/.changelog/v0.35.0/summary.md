This release fixes a bug in the packet timeout handler.

This is a consensus-breaking change.
