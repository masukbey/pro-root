- Refactor naming in the Transfer application to align with the repo naming
  conventions.
  ([#506](https://github.com/cosmos/ibc-rs/issues/506))