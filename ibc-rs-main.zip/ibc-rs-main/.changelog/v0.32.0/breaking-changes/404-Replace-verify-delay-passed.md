- Move `verify_delay_passed` process and its associated errors under the
  `ics03_connection` section and reduce entanglements with the
  `ValidationContext`.
  ([#404](https://github.com/cosmos/ibc-rs/issues/404))
