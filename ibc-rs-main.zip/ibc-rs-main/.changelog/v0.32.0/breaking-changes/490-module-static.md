- Allow for non-'static bound Modules 
  [#490](https://github.com/cosmos/ibc-rs/issues/490))
