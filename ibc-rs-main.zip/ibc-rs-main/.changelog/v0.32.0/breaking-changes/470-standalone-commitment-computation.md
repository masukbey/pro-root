Refactor and privatize Packet/Ack commitment computations for improved security
and modularity.
([#470](https://github.com/cosmos/ibc-rs/issues/470))