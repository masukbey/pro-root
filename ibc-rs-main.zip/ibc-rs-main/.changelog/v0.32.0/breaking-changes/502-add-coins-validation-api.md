- Separate the validation from the execution process for `send/mint/burn_coins`
  operations.
  ([#502](https://github.com/cosmos/ibc-rs/issues/502))