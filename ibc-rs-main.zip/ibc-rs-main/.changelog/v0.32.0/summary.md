This release primarily removes the `'static` lifetime bound on the `Module` trait,
and adds some methods to the token transfer validation trait.

There are no consensus-breaking changes.
