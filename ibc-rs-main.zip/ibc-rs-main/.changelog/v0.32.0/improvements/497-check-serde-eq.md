- In `test_serialization_roundtrip`, check that round-tripped data is equal
  ([#497](https://github.com/cosmos/ibc-rs/issues/497))