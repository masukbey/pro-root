- No longer panic when packet data is not valid UTF-8
  ([#199](https://github.com/cosmos/ibc-rs/issues/199))