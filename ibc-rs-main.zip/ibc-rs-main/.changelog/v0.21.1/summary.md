This release fixes a critical vulnerability. It is strongly advised to upgrade.
