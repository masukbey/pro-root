- Document every method of `ValidationContext` and `ExecutionContext`
  ([#376](https://github.com/cosmos/ibc-rs/issues/376))
