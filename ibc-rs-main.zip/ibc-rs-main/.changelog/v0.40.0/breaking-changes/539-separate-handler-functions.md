- Separate validation/execution handlers from context API
  ([#539](https://github.com/cosmos/ibc-rs/issues/539))
