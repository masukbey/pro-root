- Reduce and consolidate the amount of public modules exposed
  ([#235](https://github.com/cosmos/ibc-rs/issues/235))
