- Add parity-scale-codec, borsh, serde feature for *Path
  ([#652](https://github.com/cosmos/ibc-rs/issues/652))