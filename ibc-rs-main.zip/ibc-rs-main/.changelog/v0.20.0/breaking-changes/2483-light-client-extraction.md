- Redesign the API to allow light client implementations to be hosted outside the ibc-rs repository. 
  ([#2483](https://github.com/informalsystems/ibc-rs/pull/2483)).
