- Make `client_state` field required in `MsgConnectionOpenTry` and
  `MsgConnectionOpenAck`. Necessary for correctness according to spec.  
  ([#159](https://github.com/cosmos/ibc-rs/issues/159)).
