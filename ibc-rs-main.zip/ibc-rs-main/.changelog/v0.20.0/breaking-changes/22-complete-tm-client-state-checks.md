- Add missing Tendermint `ClientState` checks and make all its fields private.
- Add a `frozen_height` input parameter to `ClientState::new()`.
  ([#22](https://github.com/cosmos/ibc-rs/issues/22)).
