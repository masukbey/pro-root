- Delete packet commitment in acknowledge packet handler regardless of channel ordering
  ([#2229](https://github.com/informalsystems/ibc-rs/issues/2229)).
