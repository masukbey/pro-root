- Make client events compatible with ibc-go v5
  ([#144](https://github.com/cosmos/ibc-rs/issues/144)).
