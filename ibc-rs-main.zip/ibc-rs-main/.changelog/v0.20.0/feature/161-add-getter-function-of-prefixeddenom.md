- Public PrefixedDenom inner type and add as_str func for BaseDenom ([#161](https://github.com/cosmos/ibc-
  rs/issues/161))