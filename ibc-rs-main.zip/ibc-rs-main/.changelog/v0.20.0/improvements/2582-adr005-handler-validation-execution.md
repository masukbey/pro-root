- Propose ADR05 for handlers validation and execution separation.
  ([#2582](https://github.com/informalsystems/ibc-rs/pull/2582)).
