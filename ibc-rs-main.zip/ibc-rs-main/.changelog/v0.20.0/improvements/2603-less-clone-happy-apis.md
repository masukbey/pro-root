- Improved `core::ics04_channel` APIs, avoiding poor ergonomics of
  reference-to-tuple arguments and inconsistent ownership patterns.
  ([#2603](https://github.com/informalsystems/ibc-rs/pull/2603)).
