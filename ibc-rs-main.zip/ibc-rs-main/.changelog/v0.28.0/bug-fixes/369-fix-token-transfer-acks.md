- Fix acknowledgement returned by the token transfer's onRecvPacket callback
  ([#369](https://github.com/cosmos/ibc-rs/issues/369))