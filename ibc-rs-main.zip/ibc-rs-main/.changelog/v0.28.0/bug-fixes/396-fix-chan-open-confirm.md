- Mend `ChanOpenConfirm` handler check of expected counterparty state
  ([#396](https://github.com/cosmos/ibc-rs/issues/396))