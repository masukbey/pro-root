- Fix the caught error by `get_packet_receipt` under `val_exec_ctx` feature when
  the packet receipt is not found
  ([#409](https://github.com/cosmos/ibc-rs/issues/409))