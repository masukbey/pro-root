- Fix issue with the error handling in the `new_check_header_and_update_state`
  method when consensus state is not found
  ([#405](https://github.com/cosmos/ibc-rs/issues/405))