- Implement `verify_upgrade_and_update_state` method for Tendermint clients
  ([#19](https://github.com/cosmos/ibc-rs/issues/19)).
