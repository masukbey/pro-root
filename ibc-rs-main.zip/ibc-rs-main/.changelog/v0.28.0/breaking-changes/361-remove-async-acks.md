- Remove support for asynchronous acknowledgements
  ([#361](https://github.com/cosmos/ibc-rs/issues/361))