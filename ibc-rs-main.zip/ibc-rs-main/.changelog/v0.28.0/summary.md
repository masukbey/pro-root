With this release, the implementation of the new `ValidationContext`/`ExecutionContext` is complete, although still behind the `val_exec_ctx` feature flag. There were also important bug fixes.

There are consensus-breaking changes.
