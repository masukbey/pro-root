- Add unit tests to cover edge scenarios for counterparty conn & chan ids at init phases
  ([#175](https://github.com/cosmos/ibc-rs/issues/175)).