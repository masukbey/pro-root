This release mainly updates the tendermint-rs dependency to v0.26.0.

There are no consensus-breaking changes.
