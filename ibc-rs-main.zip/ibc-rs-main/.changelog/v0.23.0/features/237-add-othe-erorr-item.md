- Add Other Item for Ics02Client,Ics03connection, Ics04Channel Error
  ([#237](https://github.com/cosmos/ibc-rs/issues/237))