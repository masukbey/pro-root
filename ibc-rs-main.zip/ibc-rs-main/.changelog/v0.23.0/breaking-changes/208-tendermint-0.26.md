- Update to tendermint-rs 0.26 and ibc-proto 0.22
  ([#208](https://github.com/cosmos/ibc-rs/issues/208))