- Emit a message event for each IBC handling
  ([#563](https://github.com/cosmos/ibc-rs/issues/563))