This release adds the emission a `"message"` event for all handlers, which hermes currently
depends on.

There are no consensus-breaking changes.
