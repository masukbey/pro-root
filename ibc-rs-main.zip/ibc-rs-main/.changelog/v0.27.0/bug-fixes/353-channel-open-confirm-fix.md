- Fix ChanOpenConfirm handler check of counterparty state
  ([#353](https://github.com/cosmos/ibc-rs/issues/353))