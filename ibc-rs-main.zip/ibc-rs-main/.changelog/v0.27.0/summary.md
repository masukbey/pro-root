This release contains a bug fix for the `ChanOpenConfirm` handler and it is strongly recommended to upgrade.

This release contains a consensus-breaking change during the channel opening handshake; it was broken, and now is fixed.