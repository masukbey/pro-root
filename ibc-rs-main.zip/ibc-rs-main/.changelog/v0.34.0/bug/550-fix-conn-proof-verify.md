- Fix client IDs for the proof verifications in `ConnectionOpenTry` and `ConnectionOpenAck` ([#550](https://github.com/cosmos/ibc-
  rs/issues/550))
