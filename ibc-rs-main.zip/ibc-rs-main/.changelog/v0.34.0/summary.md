This release fixes a bug in the connection handshake.

This is a consensus-breaking change.
