- ChainId should serialize itself without using tendermint::chain::Id
  ([#729](https://github.com/cosmos/ibc-rs/issues/729))