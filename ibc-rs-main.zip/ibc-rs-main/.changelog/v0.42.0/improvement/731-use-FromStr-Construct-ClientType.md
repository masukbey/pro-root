- feat: use FromStr in client_type functions to construct ClientType
  ([#731](https://github.com/cosmos/ibc-rs/pull/731))