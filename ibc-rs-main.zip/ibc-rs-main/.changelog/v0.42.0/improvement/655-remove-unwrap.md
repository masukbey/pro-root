- Deny use of unwrap() throughout the crate
  ([#655](https://github.com/cosmos/ibc-rs/issues/655))