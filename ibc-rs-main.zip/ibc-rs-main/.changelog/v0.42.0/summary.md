This release primarily implements ADR 7. It also includes a number of miscellaneous improvements.

There are no consensus-breaking changes.
