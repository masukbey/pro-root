- Revise the `ChainId::new` method so that rather than taking String argument
  it borrows a str.  ([#721](https://github.com/cosmos/ibc-rs/issues/721))
