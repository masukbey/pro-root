-  Implement ADR 7, where `ClientState` objects are now statically dispatched instead
   of dynamically dispatched.
([#296](https://github.com/cosmos/ibc-rs/issues/296))
