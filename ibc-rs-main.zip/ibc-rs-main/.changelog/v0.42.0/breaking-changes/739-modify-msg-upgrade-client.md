- Modify `MsgUpgradeClient` struct to utilize `CommitmentProofBytes` and
  apply some refinements around upgrade client methods and impls respectively.
  ([#739](https://github.com/cosmos/ibc-rs/issues/739))
