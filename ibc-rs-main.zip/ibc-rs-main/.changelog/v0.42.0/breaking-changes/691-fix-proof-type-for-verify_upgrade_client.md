- Revise the `verify_upgrade_client` method to utilize the domain-specific
  `MerkleProof` type
  ([#691](https://github.com/cosmos/ibc-rs/issues/691))
