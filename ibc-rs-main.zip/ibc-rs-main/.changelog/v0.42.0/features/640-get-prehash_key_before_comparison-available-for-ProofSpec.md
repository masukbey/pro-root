- Upgrade to tendermint v0.32, ibc-proto-rs v0.32, ics23 v0.10, and get
  prehash_key_before_comparison field available for the `ProofSpec`
  ([#640](https://github.com/cosmos/ibc-rs/issues/640))
