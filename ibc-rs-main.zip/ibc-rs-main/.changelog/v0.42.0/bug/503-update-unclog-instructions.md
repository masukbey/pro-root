Remove Router::has_route
  ([\#503](https://github.com/cosmos/ibc-rs/issues/503))