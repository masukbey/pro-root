- Tendermint light client: add check that ensure that
  the consensus state timestamps are monotonic, otherwise
  freeze the client
  ([#598](https://github.com/cosmos/ibc-rs/issues/598))
