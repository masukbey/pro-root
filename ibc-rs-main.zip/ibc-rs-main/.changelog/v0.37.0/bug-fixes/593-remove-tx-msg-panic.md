- tx_msg: Remove panic in `Msg::get_sign_bytes`
  ([#593](https://github.com/cosmos/ibc-rs/issues/593))