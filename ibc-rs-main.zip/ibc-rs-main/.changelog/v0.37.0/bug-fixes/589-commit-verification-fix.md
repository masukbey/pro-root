- Tendermint light client: ensure that we use the correct
  chain ID in commit verification
  ([#589](https://github.com/cosmos/ibc-rs/issues/589))
