- Tendermint light client: fix missing trusted_validator_set 
  hash check
  ([#583](https://github.com/cosmos/ibc-rs/issues/583))
