- Tendermint light client: fix how the client's latest
  height is updated
  ([#601](https://github.com/cosmos/ibc-rs/issues/601))
