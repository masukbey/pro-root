- Disallow creation of new Tendermint client state instance with a frozen height
 ([#178](https://github.com/cosmos/ibc-rs/issues/178))