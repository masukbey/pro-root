- Tendermint light client: fix missing `Header.height()` 
  vs `Header.trusted_height` check
  ([#585](https://github.com/cosmos/ibc-rs/issues/585))
