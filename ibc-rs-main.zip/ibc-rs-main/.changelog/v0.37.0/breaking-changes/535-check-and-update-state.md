- `ClientState`: Split `check_misbehaviour_and_update_state` 
  and `check_header_and_update_state`
  ([#535](https://github.com/cosmos/ibc-rs/issues/535))
