- Check if `ClientStatePath` is empty during client creation process
  ([#604](https://github.com/cosmos/ibc-rs/issues/604))
