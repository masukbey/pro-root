- Improve MsgTransfer struct
  ([#567](https://github.com/cosmos/ibc-rs/issues/567))
