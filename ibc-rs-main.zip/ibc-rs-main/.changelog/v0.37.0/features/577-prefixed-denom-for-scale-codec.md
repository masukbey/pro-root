- Prefixed denom parity scale codec enabled
  ([#577](https://github.com/cosmos/ibc-rs/pull/577))