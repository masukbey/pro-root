- Add (de)serialization for `ics04_channel::handler::ModuleExtras`
  ([#581](https://github.com/cosmos/ibc-rs/issues/581))
