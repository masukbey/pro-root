<!--
    Add a summary for the release here.

    If you don't change this message, or if this file is empty, the release
    will not be created. -->

This release mainly updates the tendermint-rs dependency to v0.27.0 and includes security improvements.

There are no consensus-breaking changes.
