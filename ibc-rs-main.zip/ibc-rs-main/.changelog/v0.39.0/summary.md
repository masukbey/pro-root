This release primarily adds support for the `memo` field to the token transfer
app (ICS 20). This required updating ibc-proto-rs and tendermint-rs dependencies
as well.

There are consensus-breaking changes.
