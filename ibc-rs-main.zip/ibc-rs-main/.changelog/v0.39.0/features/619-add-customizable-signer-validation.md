- Define a new `ValidationContext::validate_message_signer` method to allow
  validation of the `signer` field in messages across all handlers.
  ([#619](https://github.com/cosmos/ibc-rs/issues/619))
