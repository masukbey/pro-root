- Add missing `ClientType` and `ClientId` validation checks
  ([#621](https://github.com/cosmos/ibc-rs/issues/621))
