- Bump ibc-proto to v0.29.0, bump tendermint to v0.30.0, and add `memo` field to
  `PacketData` ([#559](https://github.com/cosmos/ibc-rs/issues/559))
