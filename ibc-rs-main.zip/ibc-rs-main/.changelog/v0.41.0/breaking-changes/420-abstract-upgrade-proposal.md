- Support for upgrade client proposal by featuring helper contexts and domain types 
  ([#420](https://github.com/cosmos/ibc-rs/issues/420))
