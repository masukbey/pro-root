- Remove unused `ClientState` methods
  ([#681](https://github.com/cosmos/ibc-rs/issues/681))
