- Bump ibc-proto to v0.30.0 and tendermint to v0.31
  ([#689](https://github.com/cosmos/ibc-rs/issues/689))