- Encode upgraded client/consensus states for upgrade_client validation using `prost::Message`
  from pros ([#672](https://github.com/cosmos/ibc-rs/issues/672))
