- Clarify usage of `upgrade_path` for handling upgrade proposals
  ([#141](https://github.com/cosmos/ibc-rs/issues/141))
