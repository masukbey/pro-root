- Refactor tests for upgrade_client implementation
  ([#385](https://github.com/cosmos/ibc-rs/issues/385))
