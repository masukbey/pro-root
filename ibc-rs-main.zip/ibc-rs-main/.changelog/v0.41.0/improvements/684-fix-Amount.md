- Token transfer: Make `Amount` type less restrictive
  ([#684](https://github.com/cosmos/ibc-rs/issues/684))
