- Exclude `ClientState::new()` checks from proto ClientState conversion
  ([#671](https://github.com/cosmos/ibc-rs/issues/671))
