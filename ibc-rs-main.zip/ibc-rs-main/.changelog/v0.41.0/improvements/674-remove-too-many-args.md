- Remove redundant #[allow(clippy::too_many_arguments)]
 ([#674](https://github.com/cosmos/ibc-rs/issues/674))
