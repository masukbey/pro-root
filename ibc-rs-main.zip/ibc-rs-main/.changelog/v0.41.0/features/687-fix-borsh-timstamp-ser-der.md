- Timestamp ser and der failed on borsh feature
  ([#687](https://github.com/cosmos/ibc-rs/issues/687))