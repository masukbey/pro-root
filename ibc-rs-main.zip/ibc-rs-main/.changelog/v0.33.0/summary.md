This release primarily updates the `ClientState` trait.

There are no consensus-breaking changes.
