- Replace `ClientState::frozen_height()` and `ClientState::is_frozen()`
  with `ClientState::confirm_frozen()`
  ([#545](https://github.com/cosmos/ibc-rs/issues/545))
