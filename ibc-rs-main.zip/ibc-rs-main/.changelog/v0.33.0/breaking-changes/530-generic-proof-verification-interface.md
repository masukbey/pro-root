- Replace specific verify_functions inside `ics02_client` with generic
  `verify_membership` and `verify_non_membership` interfaces.
  ([#530](https://github.com/cosmos/ibc-rs/issues/530))
