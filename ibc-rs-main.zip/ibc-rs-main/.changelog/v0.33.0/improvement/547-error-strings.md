- Fix ContextError Display output ([#547](https://github.com/cosmos/ibc-
  rs/issues/547))