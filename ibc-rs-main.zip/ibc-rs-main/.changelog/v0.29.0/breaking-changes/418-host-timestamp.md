- Make ValidationContext::host_timestamp() abstract and remove
  ValidationContext::pending_host_consensus_state()
  ([#418](https://github.com/cosmos/ibc-rs/issues/418))
