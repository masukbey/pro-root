- Refactor get_* and store_* methods to take *Path structs instead 
  ([#382](https://github.com/cosmos/ibc-rs/issues/382))
