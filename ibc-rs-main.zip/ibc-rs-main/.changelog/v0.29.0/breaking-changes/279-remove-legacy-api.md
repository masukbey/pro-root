- Remove Reader and Keeper API ([#279](https://github.com/cosmos/ibc-
  rs/issues/279))