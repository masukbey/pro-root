- Add an implementation of `validate_self_client` for the mock client
  ([#432](https://github.com/cosmos/ibc-rs/issues/432))