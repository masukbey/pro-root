- Add a docstring and rename the "validate_self_client" argument for improved
  code documentation and readability
  ([#434](https://github.com/cosmos/ibc-rs/issues/434))
