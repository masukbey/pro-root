- Refactor connection handler unit tests to adapt with new Validation/Execution API
([#440](https://github.com/cosmos/ibc-rs/issues/440)).