- Make the code under mocks features work in no-std
  ([#311](https://github.com/cosmos/ibc-rs/issues/311))