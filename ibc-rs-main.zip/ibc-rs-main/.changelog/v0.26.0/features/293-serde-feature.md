- Make `serde` optional behind the `serde` feature flag
  ([#293](https://github.com/cosmos/ibc-rs/issues/293))
