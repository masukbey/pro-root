- Refactor unreachable test of conn_open_ack handler
  ([#30](https://github.com/cosmos/ibc-rs/issues/30))