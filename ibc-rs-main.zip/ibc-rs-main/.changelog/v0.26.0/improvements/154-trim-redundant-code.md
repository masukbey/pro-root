- Remove redundant elements and move ics18_relayer under the mock module
  ([#154](https://github.com/cosmos/ibc-rs/issues/154))