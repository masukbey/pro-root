- Improve clippy catches and fix lint issues identified by clippy 0.1.67
  ([#309](https://github.com/cosmos/ibc-rs/issues/309))