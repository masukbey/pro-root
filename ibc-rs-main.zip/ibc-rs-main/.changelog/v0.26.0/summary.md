This release contains miscellaneous improvements, focusing mainly on addressing technical debt.

There are no consensus-breaking changes.
