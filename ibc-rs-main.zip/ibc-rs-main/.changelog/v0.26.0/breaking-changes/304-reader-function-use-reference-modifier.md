- The function parameters in the Reader traits now references,
  while the functions in the Keeper traits take ownership directly.
  ([#304](https://github.com/cosmos/ibc-rs/issues/304))
