- Simplify Msg trait by removing unnecessary interfaces.
  ([#218](https://github.com/cosmos/ibc-rs/issues/218))