- Make internal `process()` `pub(crate)` 
  ([#338](https://github.com/cosmos/ibc-rs/issues/338))
