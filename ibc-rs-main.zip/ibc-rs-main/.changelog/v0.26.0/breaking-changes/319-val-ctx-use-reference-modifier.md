- The function parameters in the `ValidationContext` trait now use references,
  while the functions in the `ExecutionContext` trait take ownership directly.
  ([#319](https://github.com/cosmos/ibc-rs/issues/319))
