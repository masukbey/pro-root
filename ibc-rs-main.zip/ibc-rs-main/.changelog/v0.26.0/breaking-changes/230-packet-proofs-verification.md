- Refactor proof handlers to conduct proof verifications inline with the process function 
  and apply naming conventions to packet messages types
  ([#230](https://github.com/cosmos/ibc-rs/issues/230))
