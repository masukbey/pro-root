- Exclude `ChannelEnd` from `MsgChannelOpenInit` and `MsgChannelOpenTry` and refactor their fields to match the spec
  ([#20](https://github.com/cosmos/ibc-rs/issues/20))