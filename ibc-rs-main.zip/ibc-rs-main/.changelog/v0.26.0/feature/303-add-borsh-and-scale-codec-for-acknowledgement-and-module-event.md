- Add codec and borsh for ics04_channel::msgs::Acknowledgement and
  events::ModuleEvent ([#303](https://github.com/cosmos/ibc-rs/issues/303))