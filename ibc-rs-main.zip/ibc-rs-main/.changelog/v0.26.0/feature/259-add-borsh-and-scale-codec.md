- Add serialization and deserialization features for codec and borsh to the host
  type in ics24 ([#259](https://github.com/cosmos/ibc-rs/issues/259))