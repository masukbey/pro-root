This release contains quality of life improvements.

There are no consensus-breaking changes.
