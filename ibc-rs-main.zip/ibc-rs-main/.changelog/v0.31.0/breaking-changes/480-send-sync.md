- Remove Send + Sync supertraits on the Module trait
  ([#480](https://github.com/cosmos/ibc-rs/issues/480))