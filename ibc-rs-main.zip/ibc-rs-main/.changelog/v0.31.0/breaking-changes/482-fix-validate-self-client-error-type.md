- Modify `validate_self_client` error type to return `ContextError` instead of
  `ConnectionError` 
  ([#482](https://github.com/cosmos/ibc-rs/issues/482))