- Discard the `connction-channels` method under `ValidationContext` since it is
  no longer used by the core handler. 
  ([#479](https://github.com/cosmos/ibc-rs/issues/479))