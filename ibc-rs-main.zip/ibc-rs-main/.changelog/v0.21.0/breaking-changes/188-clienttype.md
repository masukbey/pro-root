- Make ClientType allow any string value as opposed to just Tendermint
  ([#188](https://github.com/cosmos/ibc-rs/issues/188))