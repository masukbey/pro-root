- call validate_self_client in conn_open_try and conn_open_ack,
  and provide a tendermint implementation for validate_self_client
  ([#162](https://github.com/cosmos/ibc-rs/issues/162))