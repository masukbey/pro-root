- Change ClientType to contain a String instead of &'static str
  ([#206](https://github.com/cosmos/ibc-rs/issues/206))
