- Remove crossing hellos logic from connection handshake. Breaking changes in 
  connection message types.
  ([#156](https://github.com/cosmos/ibc-rs/issues/156)).
