- Make connection events compatible with ibc-go
  ([#145](https://github.com/cosmos/ibc-rs/issues/145))