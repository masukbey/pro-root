- Refactor channel handlers. Proof calls were inlined, and our handshake
  variable naming convention was applied ([#166](https://github.com/cosmos/ibc-
  rs/issues/166))