- Makes channel/packet events compatible with ibc-go
  ([#146](https://github.com/cosmos/ibc-rs/issues/146))