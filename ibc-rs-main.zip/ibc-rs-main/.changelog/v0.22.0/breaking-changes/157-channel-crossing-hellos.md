- Remove crossing hellos logic from channel handshake
  ([#157](https://github.com/cosmos/ibc-rs/issues/157))