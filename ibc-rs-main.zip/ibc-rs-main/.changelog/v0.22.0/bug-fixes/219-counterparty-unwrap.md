- Don't panic on user input in channel proof verification
  ([#219](https://github.com/cosmos/ibc-rs/issues/219))