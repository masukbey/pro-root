- Connection consensus state proof verification now properly uses `consensus_height`
  ([#168](https://github.com/cosmos/ibc-rs/issues/168)).
