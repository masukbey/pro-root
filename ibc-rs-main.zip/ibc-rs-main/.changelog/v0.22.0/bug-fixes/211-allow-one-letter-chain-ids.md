- Allow one-letter chain names in `ChainId::is_epoch_format`
  ([#211](https://github.com/cosmos/ibc-rs/issues/211))