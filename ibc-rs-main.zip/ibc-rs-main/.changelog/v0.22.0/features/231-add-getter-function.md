- Add getter functions to SendPacket, ReceivePacket, WriteAcknowledgement,
  AcknowledgePacket, TimeoutPacket to get the elements of the structure
  ([#231](https://github.com/cosmos/ibc-rs/issues/231))